      <!-- Begin: Page Footer -->
      <footer id="content-footer">
        <div class="row">
          <div class="col-md-6">
            <span class="footer-legal">&copy; 2017 AxisMEA</span>
          </div>
          <div class="col-md-6 text-right">
            <span class="footer-meta"> <b> </b> </span>
            <a href="#content" class="footer-return-top">
              <span class="fa fa-arrow-up"></span>
            </a>
          </div>
        </div>
      </footer>
      <!-- End: Page Footer -->