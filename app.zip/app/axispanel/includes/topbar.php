      <!-- Start: Topbar -->
      <header id="topbar">
        <div class="topbar-left">
          <ol class="breadcrumb">
            <li class="crumb-active">
              <a href="index.php">
                <span class="glyphicon glyphicon-home"></span>
              </a>
            </li>
            <li class="crumb-trail"><?php if(isset($pagename)) { echo $pagename; } ?></li>
          </ol>
        </div>
      </header>
      <!-- End: Topbar -->